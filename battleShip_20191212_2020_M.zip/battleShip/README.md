# battleShip
Projekt gry w statki

Tworzenie i utrzymanie czystego kodu
Laboratorium 1
Napisz grę „statki” w wersji dla 1-ego gracza. Zastosuj znane Tobie dotąd praktyki dobrego programowania. Wydziel funkcjonalność do stosownych klas. Gra ma realizować następujące zadania:
1. Konfigurowalny rozmiar planszy w kierunki pionowym i poziomym.
2. Konfigurowalna liczba statków wraz z typami do rozmieszczenia.
3. Rozmieszczenie statków losowe/manualne.
4. Koniec gry następuje po zestrzeleniu wszystkich statków.
5. Prezentacja stanu planszy (trafiony/zatopiony/pudło).
6. Statystyka strzałów.
