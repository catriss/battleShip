﻿using System;
using System.Collections.Generic;

namespace battleShip
{
    class Program
    {
        static int oneMastShip, twoMastShip, threeMastShip;
        static int xBoardSize, yBoardSize;
        static Board board;

        static void Main(string[] args)
        {
            //Configure game.
            GameConfiguration();

            //Create ships.
            List<Ship> ShipList=new List<Ship>();

            createShips(threeMastShip, 3, ShipList);
            createShips(twoMastShip, 2, ShipList);
            createShips(oneMastShip, 1, ShipList);

            //Locate ships on board
            foreach(Ship ship in ShipList)
            {
                board.LocateShip(ship);
            }

            //Print out ships' map.
            board.PrintShipsMap();

            Console.ReadLine();
        }

        private static void GameConfiguration()
        {
            //Configure board size.
            Console.WriteLine("Podaj rozmiar x tablicy");
            xBoardSize = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Podaj rozmiar y tablicy");
            yBoardSize = Convert.ToInt32(Console.ReadLine());

            board = new Board(xBoardSize, yBoardSize);

            //Configure ship amount.
            Console.WriteLine("Podaj ilość statków jednomasztowych");
            oneMastShip = Convert.ToByte(Console.ReadLine());

            Console.WriteLine("Podaj ilość statków dwumasztowych");
            twoMastShip = Convert.ToByte(Console.ReadLine());

            Console.WriteLine("Podaj ilość statków trójmasztowych");
            threeMastShip = Convert.ToByte(Console.ReadLine());
        }

        public static void createShips(int shipType, int lives, List<Ship>ShipList)
        {
            for (byte i = 0; i < shipType; i++)
            {
                Ship newShip = new Ship(ShipList.Count + 1, lives);
                ShipList.Add(newShip);
            }
        }
    }

}


