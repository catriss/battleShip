﻿using System;
using System.Collections.Generic;
using System.Text;

namespace battleShip
{
    public class Board
    {
        #region Constants
        const int EMPTY = 0;
        const int SHOT = -1;
        #endregion

        #region Private variables
        private int xSize;
        private int ySize;
        private int[,] shipsMap;
        private int[,] shotsMap;
        #endregion

        #region Constructor
        public Board (int _xSize, int _ySize)
        {
            this.xSize = _xSize;
            this.ySize = _ySize;

            //Create ships' map.
            shipsMap = new int[_xSize, _ySize];
            InitializeMap(shipsMap);

            //Create shots' map.
            shotsMap = new int[_xSize, _ySize];
            InitializeMap(shotsMap);
        }
        #endregion

        #region Methods
        /// <summary>
        /// Initialize map with empty value
        /// </summary>
        /// <param name="_map"></param>
        private void InitializeMap(int[,] _map)
        {           
            for (int i = 0; i < _map.GetLength(0); i++)
            {
                for (int j = 0; j < _map.GetLength(1); j++)
                {
                    _map[i, j] = EMPTY;
                }
            }
        }

        #region Ship localization
        /// <summary>
        /// Locate ship on map
        /// </summary>
        /// <param name="ship"></param>
        public void LocateShip(Ship ship)
        {
            bool located = false;
            bool horizontal;
            int xOrgin, yOrgin, xEnd, yEnd;
            Random random = new Random();

            while (!located)
            {
                //Random orientation of ship.
                horizontal = ((random.Next(0, 10) % 2) == 0);

                //Random origin of ship.
                xOrgin = random.Next(0, this.xSize - 1);
                yOrgin = random.Next(0, this.ySize - 1);

                //Calculate and of ship.
                xEnd = xOrgin + ship.lives;
                yEnd = yOrgin + ship.lives;

                //Check if ship fits to board.
                if (((!horizontal && yEnd < this.ySize) || horizontal && xEnd < this.xSize) && !located)
                {
                    //Check if space is empty.
                    if (CheckSpace(horizontal, xOrgin, yOrgin, ship.lives))
                    {
                        ship.xOrgin = xOrgin;
                        ship.yOrgin = yOrgin;
                        ship.horizontal = horizontal;

                        DrawShipOnMap(ship, xOrgin, yOrgin);
                        located = true;
                    }
                }
            }
        }

        /// <summary>
        /// Check if space is empty and ready to locate ship
        /// </summary>
        /// <param name="_horizontal"></param>
        /// <param name="_xOrgin"></param>
        /// <param name="_yOrgin"></param>
        /// <param name="_shipSize"></param>
        /// <returns></returns>
        private bool CheckSpace(bool _horizontal, int _xOrgin, int _yOrgin, int _shipSize)
        {
            bool freeSpace = true;
            int xShipSize, yShipSize;

            xShipSize = _horizontal ? _shipSize : 1;
            yShipSize = _horizontal ? 1 : _shipSize;

            for (int i = _xOrgin - 1; i <= _xOrgin + xShipSize; i++)
            {
                //Check minimum & maximum of x axis
                if (i < 0 || i >= this.xSize) continue;

                for (int j = _yOrgin - 1; j <= _yOrgin + yShipSize; j++)
                {
                    //Check minimum & maximum of y axis
                    if (j < 0 || j >= this.ySize) continue;

                    //Check if space is empty
                    if (shipsMap[i,j] != EMPTY) freeSpace = false;
                }
            }

            return freeSpace;
        }

        /// <summary>
        /// Write ship id on map
        /// </summary>
        /// <param name="_ship"></param>
        /// <param name="_xOrgin"></param>
        /// <param name="_yOrgin"></param>
        private void DrawShipOnMap(Ship _ship, int _xOrgin, int _yOrgin)
        {
            if (_ship.horizontal)
            {
                for (int i = _xOrgin; i < _xOrgin + _ship.lives; i++)
                {
                    shipsMap[i, _yOrgin] = _ship.Id;
                }
            }
            else
            {
                for (int i = _yOrgin; i < _yOrgin + _ship.lives; i++)
                {
                    shipsMap[_xOrgin, i] = _ship.Id;
                }
            }
        }
        #endregion

        /// <summary>
        /// Get id of hit ship
        /// </summary>
        /// <param name="_x"></param>
        /// <param name="_y"></param>
        /// <returns></returns>
        public int GetShotResult(int _x, int _y)
        {
            if (shotsMap[_x, _y] == EMPTY)
            {
                shotsMap[_x, _y] = SHOT;
                return shipsMap[_x, _y];
            }
            else
            {
                return EMPTY;
            }
        }

        #region Print map
        public void PrintShipsMap()
        {
            Print(shipsMap);
        }

        public void PrintShotsMap()
        {
            Print(shotsMap);
        }

        private void Print(int[,] _map)
        {
            Console.WriteLine("");

            for (int i = 0; i < _map.GetLength(1); i++)
            {
                for (int j = 0; j < _map.GetLength(0); j++)
                {
                    if (j + 1 < xSize)
                    {
                        Console.Write(_map[i, j]);
                    }
                    else
                    {
                        Console.WriteLine(_map[i, j]);
                    }

                }
            }
        }
        #endregion
        #endregion
    }
}
