﻿using System;
using System.Collections.Generic;
using System.Text;

namespace battleShip
{
    public class Ship
    {
        public int lives;
        public int xOrgin, yOrgin;
        public bool horizontal;
        public int Id;
        byte shipStatus;

        public Ship(int _id, int lives)
        {
            this.lives = lives;
            this.Id = _id;
            this.shipStatus = 3;
        }
        
        

    }
}
